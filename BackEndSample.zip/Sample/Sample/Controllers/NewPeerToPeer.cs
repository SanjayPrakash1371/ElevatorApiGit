﻿namespace Sample.Controllers
{
    public class NewPeerToPeer
    {
          public string nominatorId { get; set; }
        public string empId { get; set; }



        public string? awardCategory { get; set; }

        public int? month { get; set; }

        public string? citation { get; set; }

       
    }
}
